from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class NomeVacinas(models.Model):

    nome = models.CharField(u'Nome', max_length=100)

    def __str__(self):
        return self.nome

class Postos(models.Model):

    unidade = models.CharField(u'Unidade', max_length=400)

    def __str__(self):
        return self.unidade


class Vacinas(models.Model):
    DOSES = (
        ('Unica', 'Unica'),
        ('1°', 'Primeira'),
        ('2°', 'Segunda'),
        ('3°', 'Terceira'),
    )

    nomevacinas = models.ForeignKey(NomeVacinas, verbose_name='Vacinas')
    descricao = models.CharField(u'Descrição', max_length=200)
    data = models.DateField(u'Data de Aplicação', null=True, blank=True)
    status = models.BooleanField(u'Status', blank=True)
    dose = models.CharField(u'Dose', max_length=10, choices=DOSES)
    unidade = models.ForeignKey(Postos, verbose_name='Unidade de Saúde')
    user = models.ForeignKey(User)

    def __str__(self):
        return self.nomevacinas
