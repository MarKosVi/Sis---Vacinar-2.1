from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from .models import Campanhas
# Create your views here.

def campanhas(request):
    campanhas = Campanhas.objects.all()
    context = {'campanhas': campanhas}
    return render(request, 'campanhas/campanhas.html', context)

def tutorial(request, pk):
    campanhas= Campanhas.objects.get(pk=pk)
    context = {'campanhas': campanhas}
    return render(request, 'campanhas/tutorial.html', context)