from django.conf.urls import url, include
from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static

from core import views
from vacinas import urls as vacinas_urls
from accounts import urls as accounts_urls
from mapa import urls as mapa_urls
from campanhas import urls as campanhas_urls

urlpatterns = [

    url(r'^vacinas/',include(vacinas_urls, namespace='vacinas')),
    url(r'^accounts/',include(accounts_urls, namespace='accounts')),
    url(r'^mapa',include(mapa_urls, namespace='mapa')),
    url(r'^campanhas/',include(campanhas_urls, namespace='campanhas')),
    url(r'^admin', admin.site.urls),
    url(r'',views.home, name= 'home'),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
