from django.conf.urls import url, include
from django.contrib import admin

from core import views
from vacinas import urls as vacinas_urls
from accounts import urls as accounts_urls

urlpatterns = [

    url(r'^vacinas/',include(vacinas_urls, namespace='vacinas')),
    url(r'^accounts/',include(accounts_urls, namespace='accounts')),
    url(r'^admin', admin.site.urls),
    url(r'',views.home, name= 'home'),
]
