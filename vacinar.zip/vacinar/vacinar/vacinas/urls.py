from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^nova-vacina', views.nova_vacina, name='nova_vacina'),
    url(r'^delete/(?P<id>[0-9])', views.delete, name='delete'),
]
