from django.contrib import admin
from .models import Vacinas
from .models import Postos
from .models import NomeVacinas
# Register your models here.

class VacinasAdmin(admin.ModelAdmin):
    pass

admin.site.register(Vacinas, VacinasAdmin)


class NomeVacinasAdmin(admin.ModelAdmin):
    pass

admin.site.register(NomeVacinas, NomeVacinasAdmin)


class PostosAdmin(admin.ModelAdmin):
    pass

admin.site.register(Postos, PostosAdmin)