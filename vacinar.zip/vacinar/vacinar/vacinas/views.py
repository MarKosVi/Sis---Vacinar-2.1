from django.shortcuts import render, redirect
from .forms import VacinasForm
from .models import Vacinas
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
# Create your views here.

@login_required
def nova_vacina(request):

    if request.method == 'POST':
        form = VacinasForm(request.POST)
        if form.is_valid():
            f = form.save(commit=False)
            f.user = request.user
            f.save()
            return redirect('home')

        else:
            print(form.errors)
    else:
        form = VacinasForm()
    return render(request, 'vacinas/nova_vacina.html', {'form': form})

@login_required
def delete(request, id):
    vacina = Vacinas.objects.get(id=id).delete()
    return redirect('home')