from django.apps import AppConfig


class VacinasConfig(AppConfig):
    name = 'vacinas'
