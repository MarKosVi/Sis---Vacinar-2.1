from django import forms
from .models import Vacinas


class VacinasForm(forms.ModelForm):
    class Meta:

        model = Vacinas
        exclude = ['descricao', 'user']
