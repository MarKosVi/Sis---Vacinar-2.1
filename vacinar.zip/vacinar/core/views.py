from django.shortcuts import render
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
from vacinas.models import Vacinas

# Create your views here.
@login_required
def home(request):
    vacinas = Vacinas.objects.filter(user=request.user)
    context = {'vacinas': vacinas}
    return render(request, 'index/index.html', context)
