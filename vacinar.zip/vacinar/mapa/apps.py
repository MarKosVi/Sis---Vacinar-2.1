from django.apps import AppConfig


class MapaConfig(AppConfig):
    name = 'mapa'
