from django.db import models

# Create your models here.

class AdmCampanhas(models.Manager):
    def search(self, query):
        return self.get_queryset().filter(
            models.Q(name_icontains=query) |
            models.Q(descricao_icontains=query))


class Campanhas (models.Model):

    name = models.CharField('Nome', max_length=100)
    slug = models.SlugField('Atalho')
    descricao = models.TextField('Descrição', blank=True)
    about = models.TextField('Sobre', blank=True)
    data = models.DateField(
        'Data de Inicio', null=True, blank=True
    )
    imagem = models.ImageField(upload_to='campanhas/imagens', verbose_name='Imagem',
                               null=True, blank=True)

    created_at = models.DateTimeField('Criado em ', auto_now_add=True)
    updated_at = models.DateTimeField('Atualizado em ', auto_now=True)

    objects = AdmCampanhas()

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Campanha'
        verbose_name_plural = 'Campanhas'
        ordering = ['name']


class AdmDetalhes(models.Manager):
    def search(self, query):
        return self.get_queryset().filter(
            models.Q(name_icontains=query) |
            models.Q(descricao_icontains=query))


class Detalhes (models.Model):

    name = models.CharField('Nome', max_length=100)
    slug = models.SlugField('Atalho')
    descricao = models.TextField('Descrição', blank=True)
    about = models.TextField('Sobre', blank=True)
    data = models.DateField(
        'Data de Inicio', null=True, blank=True
    )
    imagem = models.ImageField(upload_to='detalhes/imagens', verbose_name='Imagem',
                               null=True, blank=True)

    created_at = models.DateTimeField('Criado em ', auto_now_add=True)
    updated_at = models.DateTimeField('Atualizado em ', auto_now=True)

    objects = AdmDetalhes()

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Detalhe'
        verbose_name_plural = 'Detalhes'
        ordering = ['name']