from django.conf.urls import url, patterns, include
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    url(r'^/', views.campanhas, name='campanhas'),
    url(r'^(?P<pk>\d+)', views.tutorial, name='tutorial'),

]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)