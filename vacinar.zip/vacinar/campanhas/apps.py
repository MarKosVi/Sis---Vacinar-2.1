from django.apps import AppConfig


class CampanhasConfig(AppConfig):
    name = 'campanhas'
