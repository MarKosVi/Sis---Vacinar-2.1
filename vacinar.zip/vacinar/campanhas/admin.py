from django.contrib import admin
from .models import Campanhas
from .models import Detalhes

class AdmCampanhas(admin.ModelAdmin):
    list_display = ['name', 'slug', 'data', 'created_at']
    search_fields = ['name', 'slug']

admin.site.register(Campanhas, AdmCampanhas)


class AdmDetalhes(admin.ModelAdmin):
    list_display = ['name', 'slug', 'data', 'created_at']
    search_fields = ['name', 'slug']

admin.site.register(Detalhes, AdmDetalhes)