from django.contrib import admin
from .models import Campanhas

class AdmCampanhas(admin.ModelAdmin):
    list_display = ['name', 'slug', 'data', 'created_at']
    search_fields = ['name', 'slug']

admin.site.register(Campanhas, AdmCampanhas)
